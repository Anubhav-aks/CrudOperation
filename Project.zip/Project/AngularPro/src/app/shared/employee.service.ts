import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';

import { Employee } from './employee.model'

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  selectedEmployee=new Employee("","","","",null);
  employees: Employee[];
  readonly baseUrl = 'http://localhost:3000/employees';
  constructor(public http: HttpClient) { }
  postEmployee(emp: Employee): Observable<any> {

    return this.http.post(this.baseUrl, emp);

  }
  getEmployeeList() {
    return this.http.get(this.baseUrl)
  }
  putEmployee(emp:Employee) {
    return this.http.put(this.baseUrl +`/${emp._id}`, emp)
  }
  deleteEmployee(_id:string):Observable<any>{
    return this.http.delete(this.baseUrl +`/${_id}`)
  }

}
